i

# Jenkins Pipeline Sample Jenkins Script

This GitHub repository contains one single Jenkinsfile that is used to demonstrate a simple Jenkins pipeline concept.

The repository was created to support the article written for [Opensource.com](https://opensource.com)

